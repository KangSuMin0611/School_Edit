package com.smc.firstapp.model;

public class ListItem {

    public String title;
    public String link;
    public String image;
    public int lprice;
    public String mallName;

}
