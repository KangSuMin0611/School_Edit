package com.smc.firstapp.model;

import java.util.ArrayList;

public class SearchRes {
    public int total;
    public int start;
    public int display;
    public ArrayList<ListItem> items;
}
