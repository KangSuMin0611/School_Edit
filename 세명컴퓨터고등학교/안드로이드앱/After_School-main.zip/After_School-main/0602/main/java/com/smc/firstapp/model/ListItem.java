package com.smc.firstapp.model;

public class ListItem {

    public String title;
    public String desc;


    public ListItem(String title, String desc) {
        this.desc = desc;
        this.title = title;
    }
}
