package project0318;

public class Point3D extends Point {
	
	public int z;
	
	

	public int getZ() {
		return z;
	}

	public void setZ(int z) {
		this.z = z;
	}
	
}
