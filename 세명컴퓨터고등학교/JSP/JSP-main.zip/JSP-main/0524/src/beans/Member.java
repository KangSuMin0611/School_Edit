package beans;

public class Member {
	
	private String id;
	private String pw;
	
	
}
